<?php

/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package pnplw2022
 */

get_header();
?>


<div class="container">
    <div class="row justify-content-md-center">

        <div class="col-md-auto">
           <?php echo do_shortcode('[metaslider id="7998"]'); ?>
            <img alt="" src="<?php echo get_template_directory_uri(); ?>/img/header1.png">
        </div>

    </div>
    <nav class="breadcrumb" aria-label="breadcrumb">
        <ol>
            <li class="breadcrumb-item"><a href="Link">Home >> Beranda Justicia</a></li>

        </ol>
    </nav>
     <div class="row justify-content-md-center">
        <div class="col-12 bg-merah">
            <div class="mx-auto" style="width: 1000px;">
                <img src=" <?php echo get_template_directory_uri(); ?>/img/motto.jpg">
            </div>
        </div>
    </div>
</div>
<div class="container bg-abu">
    <<div class="row ${1| ,row-cols-2,row-cols-3, auto,justify-content-md-center,|}">
        b5-col
</div>

<div class="row justify-content-md-center">
    <div class="col-md-auto"><?php get_sidebar(); ?>1</div>
    <div class="col-md-auto"><?php get_sidebar(); ?>2</div>

    <div class="col-md-auto"><?php get_sidebar(); ?>3</div>





</div><!-- .col-12 .col-md-4 -->

</div><!-- .row -->
</div><!-- .container -->
<?php

get_footer();